#!/usr/bin/env python3
"""Script limpo para filtrar valores > threshold do CSV.

Cada linha do CSV deve conter uma única célula com uma lista Python,
por exemplo: "[0.98, 2.51, ...]". O script escreve `ecg_pulse_filtered.csv` por padrão.

Uso:
  python .\filter_values.py -i ecg_pulse.csv -o ecg_pulse_filtered.csv -t 30.0
"""

import ast
import csv
import argparse
import sys
from typing import Any, List


def parse_list_str(s: str) -> Any:
    s = s.strip()
    if (s.startswith('"') and s.endswith('"')) or (s.startswith("'") and s.endswith("'")):
        s = s[1:-1]
    try:
        return ast.literal_eval(s)
    except Exception:
        try:
            return ast.literal_eval(s.replace('"', '').replace("'", ''))
        except Exception:
            return None


def main() -> None:
    parser = argparse.ArgumentParser(
        description='Filtra valores maiores que um limite no CSV.')
    parser.add_argument('-i', '--input', default='ecg_pulse.csv',
                        help='Arquivo CSV de entrada')
    parser.add_argument(
        '-o', '--output', default='ecg_pulse_filtered.csv', help='Arquivo CSV de saída')
    parser.add_argument('-t', '--threshold', type=float,
                        default=30.0, help='Limite (valores > lim são removidos)')
    args = parser.parse_args()

    total_before = 0
    total_after = 0
    rows = 0
    processed_rows: List[Any] = []

    try:
        with open(args.input, newline='', encoding='utf-8') as f_in:
            reader = csv.reader(f_in)
            for row in reader:
                rows += 1
                out_fields: List[Any] = []
                for field in row:
                    parsed = parse_list_str(field)
                    if isinstance(parsed, (list, tuple)):
                        total_before += len(parsed)
                        filtered = [x for x in parsed if isinstance(
                            x, (int, float)) and x <= args.threshold]
                        total_after += len(filtered)
                        out_fields.append(filtered)
                    else:
                        try:
                            val = float(field)
                            total_before += 1
                            if val <= args.threshold:
                                total_after += 1
                                out_fields.append(val)
                        except Exception:
                            out_fields.append(field)
                processed_rows.append(out_fields)
    except FileNotFoundError:
        print(f"Arquivo de entrada não encontrado: {args.input}")
        sys.exit(1)

    with open(args.output, 'w', newline='', encoding='utf-8') as f_out:
        writer = csv.writer(f_out, quoting=csv.QUOTE_ALL)
        for fields in processed_rows:
            if len(fields) == 1 and isinstance(fields[0], list):
                writer.writerow([str(fields[0])])
            else:
                writer.writerow([str(fields)])

    print(f"Linhas processadas: {rows}")
    print(
        f"Valores antes: {total_before}, depois: {total_after}, removidos: {total_before - total_after}")
    print(f"Arquivo filtrado salvo em: {args.output}")


if __name__ == '__main__':
    main()
