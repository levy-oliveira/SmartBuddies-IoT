import pandas as pd
import numpy as np
import ast

# ---------------------------------------------------------------------
# Funções utilitárias para extrair métricas de HRV
# ---------------------------------------------------------------------


def compute_rr_intervals(timestamps):
    """Recebe uma lista de timestamps e retorna os intervalos RR."""
    timestamps = np.array(timestamps)
    return np.diff(timestamps)


def compute_hrv_features(timestamps):
    """Calcula todas as features de HRV a partir dos timestamps do ECG."""
    if len(timestamps) < 2:
        return {
            "n_beats": len(timestamps),
            "duration_s": 0,
            "mean_rr": 0,
            "sd_rr": 0,
            "rmssd": 0,
            "min_rr": 0,
            "max_rr": 0,
            "bpm": 0,
            "pnn50": 0,
        }

    # RR intervals
    rr = compute_rr_intervals(timestamps)

    # Métricas de HRV
    mean_rr = np.mean(rr)
    sd_rr = np.std(rr)
    rmssd = np.sqrt(np.mean(np.square(np.diff(rr)))) if len(rr) > 1 else 0
    min_rr = np.min(rr)
    max_rr = np.max(rr)
    bpm = 60.0 / mean_rr if mean_rr > 0 else 0

    # pNN50 (intervalos RR > 50 ms = 0.05s)
    diff_rr = np.abs(np.diff(rr))
    pnn50 = np.sum(diff_rr > 0.05) / len(diff_rr) if len(diff_rr) > 0 else 0

    return {
        "n_beats": len(timestamps),
        "duration_s": timestamps[-1] - timestamps[0],
        "mean_rr": mean_rr,
        "sd_rr": sd_rr,
        "rmssd": rmssd,
        "min_rr": min_rr,
        "max_rr": max_rr,
        "bpm": bpm,
        "pnn50": pnn50
    }

# ---------------------------------------------------------------------
# Leitura do arquivo enviado
# ---------------------------------------------------------------------


csv_path = "ecg_pulse_filtered - ecg_pulse_filtered.csv"

# O CSV fornecido não tem cabeçalho: cada linha é uma string com o vetor.
# Lemos sem header e nomeamos a coluna `ecg_pulse` para compatibilidade.
df = pd.read_csv(csv_path, header=None, names=["ecg_pulse"])

# Supondo que sua coluna com o vetor ECG se chama "ecg_pulse"
# Caso o nome seja diferente, diga-me qual é e ajusto o código

FEATURES = [
    "n_beats", "duration_s", "mean_rr", "sd_rr", "rmssd",
    "min_rr", "max_rr", "bpm", "pnn50"
]

results = []

for idx, row in df.iterrows():
    try:
        # Converte string "[0.1, 0.3, ...]" para lista de floats
        timestamps = ast.literal_eval(row["ecg_pulse"])

        # Calcula features
        feats = compute_hrv_features(timestamps)
        feats["rec_id"] = idx

        results.append(feats)

    except Exception as e:
        print(f"Erro na linha {idx}: {e}")

# ---------------------------------------------------------------------
# Criar DataFrame final
# ---------------------------------------------------------------------

df_out = pd.DataFrame(results)

# Se nada foi computado, avisa e encerra sem tentar reordenar colunas inexistentes
if df_out.empty:
    print("Nenhuma feature foi calculada. Verifique o arquivo CSV e o nome da coluna.")
else:
    # Reordenar colunas
    df_out = df_out[["rec_id"] + FEATURES]

    # Salvar CSV final
    output_path = "ecg_hrv_features.csv"
    df_out.to_csv(output_path, index=False)
    print(f"Features salvas em: {output_path}")
