
#!/usr/bin/env python3
"""Particiona cada lista do CSV em blocos de largura fixa (ex.: 30.0).

Cada linha do CSV fonte deve conter uma única célula com uma lista Python,
por exemplo: "[0.98, 2.51, ...]". O script gera `ecg_pulse_partitioned.csv`,
onde cada elemento original pode produzir várias linhas — uma por faixa:
- [0.00, 30.00]
- (30.00, 60.00]
- (60.00, 90.00]
  e assim por diante até cobrir os valores presentes.

Uso:
  python .\filtered_values2.py -i ecg_pulse.csv -o ecg_pulse_partitioned.csv -w 30.0
"""

import ast
import csv
import argparse
import sys
from typing import Any, List, Iterable, Tuple


def parse_list_str(s: str) -> Any:
    s = s.strip()
    if (s.startswith('"') and s.endswith('"')) or (s.startswith("'") and s.endswith("'")):
        s = s[1:-1]
    try:
        return ast.literal_eval(s)
    except Exception:
        try:
            return ast.literal_eval(s.replace('"', '').replace("'", ''))
        except Exception:
            return None


def partition_values(values: Iterable[float], width: float) -> List[Tuple[float, float, List[float]]]:
    """Partitiona uma sequência de valores em faixas de largura `width`.

    Retorna uma lista de tuplas (start, end, valores_na_faixa).
    A primeira faixa é [0, width], faixas subsequentes são (prev_end, end].
    """
    vals = sorted([v for v in values if isinstance(v, (int, float))])
    if not vals:
        return []

    max_v = vals[-1]
    ranges: List[Tuple[float, float, List[float]]] = []
    # cria faixas de 0..width, (width..2*width], ... até cobrir max_v
    start = 0.0
    end = width
    idx = 0
    n = len(vals)
    while start < max_v + 1e-12:
        bucket: List[float] = []
        # incluir valores: <= end and > start (except first bucket includes start)
        while idx < n and vals[idx] <= end:
            if start == 0.0:
                # inclui valores >= 0 e <= end
                if vals[idx] >= 0.0:
                    bucket.append(vals[idx])
            else:
                # inclui apenas valores > start and <= end
                if vals[idx] > start:
                    bucket.append(vals[idx])
            idx += 1
        ranges.append((start, end, bucket))
        start = end
        end = round(end + width, 12)
        if idx >= n:
            # se já consumimos todos os valores, mas queremos ainda listar faixas vazias até o último não é necessário
            break

    return ranges


def main() -> None:
    parser = argparse.ArgumentParser(
        description='Particiona listas do CSV em faixas de largura fixa.')
    parser.add_argument('-i', '--input', default='ecg_pulse.csv',
                        help='Arquivo CSV de entrada')
    parser.add_argument(
        '-o', '--output', default='ecg_pulse_partitioned.csv', help='Arquivo CSV de saída')
    parser.add_argument('-w', '--width', type=float,
                        default=30.0, help='Largura da faixa (ex: 30.0)')
    args = parser.parse_args()

    input_rows = 0
    output_rows = 0
    try:
        with open(args.input, newline='', encoding='utf-8') as f_in:
            reader = csv.reader(f_in)
            partitioned_lines: List[List[float]] = []
            for row in reader:
                input_rows += 1
                if not row:
                    continue
                parsed = parse_list_str(row[0])
                if not isinstance(parsed, (list, tuple)):
                    # pula linhas malformadas
                    continue
                # particiona os valores numéricos
                ranges = partition_values(parsed, args.width)
                for (start, end, bucket) in ranges:
                    if bucket:
                        partitioned_lines.append(bucket)
                        output_rows += 1
    except FileNotFoundError:
        print(f"Arquivo de entrada não encontrado: {args.input}")
        sys.exit(1)

    # escreve CSV de saída: cada linha uma lista (string)
    with open(args.output, 'w', newline='', encoding='utf-8') as f_out:
        writer = csv.writer(f_out, quoting=csv.QUOTE_ALL)
        for bucket in partitioned_lines:
            writer.writerow([str(bucket)])

    print(f"Linhas de entrada: {input_rows}")
    print(f"Linhas de saída (partições geradas): {output_rows}")
    print(f"Arquivo salvo em: {args.output}")


if __name__ == '__main__':
    main()
