#!/usr/bin/env python3
"""Filtra valores maiores que um limite em cada linha do CSV.

Formato esperado:
- Cada linha contém uma única célula com uma lista Python (ex: "[0.98, 2.51, ...]").

Saída:
- `ecg_pulse_filtered.csv` por padrão: cada linha com a lista filtrada (valores <= threshold).

Uso:
  python .\filter.py -i ecg_pulse.csv -o ecg_pulse_filtered.csv -t 30.0
"""

import ast
import csv
import argparse
import sys
from typing import Any, List


def parse_list_str(s: str) -> Any:
    s = s.strip()
    # Remove surrounding quotes se existirem
    if (s.startswith('"') and s.endswith('"')) or (s.startswith("'") and s.endswith("'")):
        s = s[1:-1]
    try:
        return ast.literal_eval(s)
    except Exception:
        # Tenta remover aspas internas e tentar novamente
        try:
            return ast.literal_eval(s.replace('"', '').replace("'", ''))
        except Exception:
            return None


def filter_row_field(field: Any, threshold: float) -> Any:
    if isinstance(field, (list, tuple)):
        #!/usr/bin/env python3
        """Filtra valores maiores que um limite em cada linha do CSV.

        Formato esperado:
        - Cada linha contém uma única célula com uma lista Python (ex: "[0.98, 2.51, ...]").

        Saída:
        - `ecg_pulse_filtered.csv` por padrão: cada linha com a lista filtrada (valores <= threshold).

        Uso:
          python .\filter.py -i ecg_pulse.csv -o ecg_pulse_filtered.csv -t 30.0
        """

        import ast
        import csv
        import argparse
        import sys
        from typing import Any, List

        def parse_list_str(s: str) -> Any:
            s = s.strip()
            # Remove surrounding quotes se existirem
            if (s.startswith('"') and s.endswith('"')) or (s.startswith("'") and s.endswith("'")):
                s = s[1:-1]
            try:
                return ast.literal_eval(s)
            except Exception:
                # Tenta remover aspas internas e tentar novamente
                try:
                    return ast.literal_eval(s.replace('"', '').replace("'", ''))
                except Exception:
                    return None

        def filter_row_field(field: Any, threshold: float) -> Any:
            if isinstance(field, (list, tuple)):
                filtered = [x for x in field if isinstance(
                    x, (int, float)) and x <= threshold]
                return filtered
            # se for um valor simples
            try:
                f = float(field)
                return f if f <= threshold else None
            except Exception:
                return field

        def main() -> None:
            parser = argparse.ArgumentParser(
                description='Filtra valores maiores que um limite no CSV.')
            parser.add_argument(
                '-i', '--input', default='ecg_pulse.csv', help='Arquivo CSV de entrada')
            parser.add_argument(
                '-o', '--output', default='ecg_pulse_filtered.csv', help='Arquivo CSV de saída')
            parser.add_argument('-t', '--threshold', type=float,
                                default=30.0, help='Limite (valores > lim são removidos)')
            args = parser.parse_args()

            total_before = 0
            total_after = 0
            rows = 0
            processed_rows: List[Any] = []

            try:
                with open(args.input, newline='', encoding='utf-8') as f_in:
                    reader = csv.reader(f_in)
                    for row in reader:
                        rows += 1
                        out_fields: List[Any] = []
                        for field in row:
                            parsed = parse_list_str(field)
                            if isinstance(parsed, (list, tuple)):
                                total_before += len(parsed)
                                filtered = [x for x in parsed if isinstance(
                                    x, (int, float)) and x <= args.threshold]
                                total_after += len(filtered)
                                out_fields.append(filtered)
                            else:
                                # tenta interpretar como número isolado
                                try:
                                    val = float(field)
                                    total_before += 1
                                    if val <= args.threshold:
                                        total_after += 1
                                        out_fields.append(val)
                                    else:
                                        # elemento removido -> não adiciona
                                        pass
                                except Exception:
                                    # campo não numérico: apenas preserva
                                    out_fields.append(field)
                        processed_rows.append(out_fields)
            except FileNotFoundError:
                print(f"Arquivo de entrada não encontrado: {args.input}")
                sys.exit(1)

            # Escreve saída: cada linha com uma célula contendo a lista filtrada (entre aspas)
            with open(args.output, 'w', newline='', encoding='utf-8') as f_out:
                writer = csv.writer(f_out, quoting=csv.QUOTE_ALL)
                for fields in processed_rows:
                    # Se a linha tinha a forma original de uma única lista, escrevemos a lista filtrada
                    if len(fields) == 1 and isinstance(fields[0], list):
                        writer.writerow([str(fields[0])])
                    else:
                        # escrever representação simples das fields
                        writer.writerow([str(fields)])

            print(f"Linhas processadas: {rows}")
            print(
                f"Valores antes: {total_before}, depois: {total_after}, removidos: {total_before - total_after}")
            print(f"Arquivo filtrado salvo em: {args.output}")

        if __name__ == '__main__':
            main()
    if isinstance(field, (list, tuple)):

        #!/usr/bin/env python3
        """Filtra valores maiores que um limite em cada linha do CSV.

        Formato esperado:
        - Cada linha contém uma única célula com uma lista Python (ex: "[0.98, 2.51, ...]").

        Saída:
        - `ecg_pulse_filtered.csv` por padrão: cada linha com a lista filtrada (valores <= threshold).

        Uso:
          python .\filter.py -i ecg_pulse.csv -o ecg_pulse_filtered.csv -t 30.0
        """

        from __future__ import annotations
        import ast
        import csv
        import argparse
        import sys
        from typing import Any, List

        def parse_list_str(s: str) -> Any:
            s = s.strip()
            # Remove surrounding quotes se existirem
            if (s.startswith('"') and s.endswith('"')) or (s.startswith("'") and s.endswith("'")):
                s = s[1:-1]
            try:
                return ast.literal_eval(s)
            except Exception:
                # Tenta remover aspas internas e tentar novamente
                try:
                    return ast.literal_eval(s.replace('"', '').replace("'", ''))
                except Exception:
                    return None

        def filter_row_field(field: Any, threshold: float) -> Any:
            if isinstance(field, (list, tuple)):
                filtered = [x for x in field if isinstance(
                    x, (int, float)) and x <= threshold]
                return filtered
            # se for um valor simples
            try:
                f = float(field)
                return f if f <= threshold else None
            except Exception:
                return field

        def main() -> None:
            parser = argparse.ArgumentParser(
                description='Filtra valores maiores que um limite no CSV.')
            parser.add_argument(
                '-i', '--input', default='ecg_pulse.csv', help='Arquivo CSV de entrada')
            parser.add_argument(
                '-o', '--output', default='ecg_pulse_filtered.csv', help='Arquivo CSV de saída')
            parser.add_argument('-t', '--threshold', type=float,
                                default=30.0, help='Limite (valores > lim são removidos)')
            args = parser.parse_args()

            total_before = 0
            total_after = 0
            rows = 0
            processed_rows: List[Any] = []

            try:
                with open(args.input, newline='', encoding='utf-8') as f_in:
                    reader = csv.reader(f_in)
                    for row in reader:
                        rows += 1
                        out_fields: List[Any] = []
                        for field in row:
                            parsed = parse_list_str(field)
                            if isinstance(parsed, (list, tuple)):
                                total_before += len(parsed)
                                filtered = [x for x in parsed if isinstance(
                                    x, (int, float)) and x <= args.threshold]
                                total_after += len(filtered)
                                out_fields.append(filtered)
                            else:
                                # tenta interpretar como número isolado
                                try:
                                    val = float(field)
                                    total_before += 1
                                    if val <= args.threshold:
                                        total_after += 1
                                        out_fields.append(val)
                                    else:
                                        # elemento removido -> não adiciona
                                        pass
                                except Exception:
                                    # campo não numérico: apenas preserva
                                    out_fields.append(field)
                        processed_rows.append(out_fields)
            except FileNotFoundError:
                print(f"Arquivo de entrada não encontrado: {args.input}")
                sys.exit(1)

            # Escreve saída: cada linha com uma célula contendo a lista filtrada (entre aspas)
            with open(args.output, 'w', newline='', encoding='utf-8') as f_out:
                writer = csv.writer(f_out, quoting=csv.QUOTE_ALL)
                for fields in processed_rows:
                    # Se a linha tinha a forma original de uma única lista, escrevemos a lista filtrada
                    if len(fields) == 1 and isinstance(fields[0], list):
                        writer.writerow([str(fields[0])])
                    else:
                        # escrever representação simples das fields
                        writer.writerow([str(fields)])

            print(f"Linhas processadas: {rows}")
            print(
                f"Valores antes: {total_before}, depois: {total_after}, removidos: {total_before - total_after}")
            print(f"Arquivo filtrado salvo em: {args.output}")

        if __name__ == '__main__':
            main()
