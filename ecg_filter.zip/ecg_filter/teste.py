import pandas as pd
import numpy as np

# Carrega seu arquivo
df = pd.read_csv('ecg_hrv_features copy 2.csv')

anomalies = []

# Função auxiliar para gerar número dentro de um intervalo
rand = np.random.uniform

for i in range(40):  # gera 40 anomalias (20 de cada tipo)

    # --- Tipo 1: Taquicardia extrema ---
    anomalies.append({
        "rec_id": 9000 + i,
        "n_beats": int(rand(120, 200)),
        "duration_s": rand(20, 35),
        "mean_rr": rand(0.30, 0.45),     # intervalos muito curtos
        "sd_rr": rand(0.20, 0.60),
        "rmssd": rand(0.30, 0.90),
        "min_rr": rand(0.20, 0.40),
        "max_rr": rand(0.60, 1.20),
        "bpm": rand(120, 180),
        "pnn50": rand(0.00, 0.30),
        "Expected outcome": "anomaly"
    })

    # --- Tipo 2: Arritmia severa ---
    anomalies.append({
        "rec_id": 9500 + i,
        "n_beats": int(rand(20, 60)),
        "duration_s": rand(20, 35),
        "mean_rr": rand(0.60, 1.20),
        "sd_rr": rand(0.50, 1.20),        # variação absurda
        "rmssd": rand(0.50, 1.20),
        "min_rr": rand(0.30, 0.60),
        "max_rr": rand(1.50, 2.50),
        "bpm": rand(40, 140),
        "pnn50": rand(0.80, 1.00),        # variabilidade explode
        "Expected outcome": "anomaly"
    })

# Converte para DF
df_anom = pd.DataFrame(anomalies)

# Salva o arquivo pronto para upload no Edge Impulse
output_path = "ecg_anomalies_generated.csv"
df_anom.to_csv(output_path, index=False)

output_path
